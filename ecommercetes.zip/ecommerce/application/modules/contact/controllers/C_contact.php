<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_contact extends MX_Controller {

	public function index()
	{
		$content['title']  = 'Contact';

		$this->load->view('menu/V_header', $content);
		if ($this->session->userdata('ec_role') == 'Member') {
			$this->load->view('menu/V_menu_login');
		}
		else{
			$this->load->view('menu/V_menu');
		}
		$this->load->view('V_content');
		$this->load->view('menu/V_footer');
	}

}

/* End of file C_contact.php */
/* Location: ./application/modules/contact/controllers/C_contact.php */