<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_login extends MX_Controller {

	public function __construct()
	{
		parent::__construct();
		date_default_timezone_set("Asia/Jakarta");
		$this->load->model('login/M_login');
	}

	public function index()
	{
		$content['title']   = 'Login Page';

		$this->load->view('menu/V_header', $content);
		$this->load->view('menu/V_menu');
		$this->load->view('V_content');
		$this->load->view('menu/V_footer');
	}

	public function login(){

		if ($this->session->userdata('ec_role') == 'Member') {
			redirect(base_url());
		}
		else{
			$email    = $this->input->post('email');
			$password = $this->input->post('password');
	
			if (empty($email) || empty($password)) {
				$this->session->set_flashdata('wrong', '<div class="alert alert-danger">Username atau Password Tidak Boleh Kosong</div>');
				redirect('login');
			}
			else{

				$login = $this->M_login->checkLogin($email);
				$cek 	  = $login->row_array();
				if ($login->num_rows() < 1) {
					$this->session->set_flashdata('wrong', '<div class="alert alert-danger">Email atau Username Salah</div>');
					redirect('login');
				}
				else if (!password_verify($password, $cek['pass'])) {
					$this->session->set_flashdata('wrong', '<div class="alert alert-danger">Password Salah</div>');
					redirect('login');
				}
				else{
					$user_id  = $cek['user_id'];
					$photo    = $cek['photo'];
					$email    = $cek['email'];
					$username = $cek['login'];
					$role     = 'Member';

					$where = array('user_id' => $user_id);
					$data  = array('last_login' => date('Y-m-d H:i:s'));
					$this->M_login->lastLog($where, 'ec_user', $data);

					$data_session = array(
										'ec_user_id'  => $user_id,
										'ec_photo'    => $photo,
										'ec_email'    => $email,
										'ec_username' => $username,
										'ec_role'     => $role
									);
					$this->session->set_userdata($data_session);
					redirect(base_url());
				}

			}

		}

	}

	public function logout(){
		$email = $this->session->userdata('ec_email');
		$where = array('email' => $email);
		$data  = array('last_login' => date('Y-m-d H:i:s'));
		$this->M_login->lastLog($where, 'ec_user', $data);

		$this->cart->destroy();
		$this->session->sess_destroy();
		redirect(base_url());
	}

}

/* End of file C_login.php */
/* Location: ./application/modules/login/controllers/C_login.php */