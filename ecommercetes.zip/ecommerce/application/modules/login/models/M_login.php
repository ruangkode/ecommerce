<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_login extends CI_Model {

	public function checkLogin($email_username){
		$this->db->select('ec_user.user_id, login, photo, email, pass')
				 ->from('ec_user')
				 ->join('ec_user_detail', 'ec_user_detail.user_id = ec_user.user_id', 'inner')
				 ->where('email', $email_username)
				 ->where('is_locked', '0')
				 ->where('approve', '1')
				 ->where('active_user', '1')
				 ->where('active_detail_user', '1')
				 ->or_where('login', $email_username)
				 ->where('is_locked', '0')
				 ->where('approve', '1')
				 ->where('active_user', '1')
				 ->where('active_detail_user', '1');
		$data = $this->db->get();
		return $data;
	}

	public function lastLog($where, $table, $data){
		$this->db->where($where);
		$this->db->update($table, $data);
	}

}

/* End of file M_login.php */
/* Location: ./application/modules/login/models/M_login.php */