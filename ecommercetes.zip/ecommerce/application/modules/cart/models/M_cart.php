<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_cart extends CI_Model {

	public function insertTransaction($table, $data){
		$res = $this->db->insert($table, $data);
		return $res;
	}

	public function getMaxIdTransaction($user_id){
		$this->db->select('transaction_id')
				 ->from('ec_transaction')
				 ->select_max('transaction_id')
				 ->where('user_id', $user_id);
		$data = $this->db->get();
		return $data->row_array();
	}

	public function insertProduct($table, $data){
		$res = $this->db->insert($table, $data);
		return $res;
	}

}

/* End of file M_cart.php */
/* Location: ./application/modules/cart/models/M_cart.php */