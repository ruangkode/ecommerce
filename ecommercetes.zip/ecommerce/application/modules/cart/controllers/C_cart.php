<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_cart extends MX_Controller {

	public function __construct()
	{
		parent::__construct();
		date_default_timezone_set("Asia/Jakarta");
		$this->load->model(array('product_detail/M_product_detail', 'cart/M_cart'));
		$this->load->library(array('user_agent', 'cart'));
	}
	
	public function index()
	{
		$content['title']  = 'Cart Shop';
		$data['cart'] 	   = $this->cart->contents();

		$this->load->view('menu/V_header', $content);
		if ($this->session->userdata('ec_role') == 'Member') {
			$this->load->view('menu/V_menu_login');
		}
		else{
			$this->load->view('menu/V_menu');
		}
		$this->load->view('V_content', $data);
		$this->load->view('menu/V_footer');
	}

	public function add_cart(){
		if ($this->session->userdata('ec_role') == 'Member') {
			$slug = $this->input->post('slug');
			$qty  = $this->input->post('qty');
			if (!empty($this->M_product_detail->checkProductId($slug))) {

				$detail = $this->M_product_detail->getProductDetail($slug);

				if ($detail['stock'] < $qty) {
					$this->session->set_flashdata('wrong', '<div class="alert alert-danger">Product stock is not enough</div>');
					redirect('product/'.$slug);
				}
				else{
					$data = array(
						'product_image' => $detail['product_image'],
			            'id' 			=> $detail['product_id'], 
			            'name' 			=> $detail['product'], 
			            'price' 		=> $detail['price'], 
			            'discount' 		=> $detail['discount'],
			            'weight'		=> $detail['weight'],
			            'qty' 			=> $qty 
			        );

			        if ($this->cart->insert($data)) {
			        	$cart = $this->cart->contents();
			        	redirect(base_url().'cart','refresh');
			        }
			        else{
			        	redirect(base_url(),'refresh');
			        }
				}

			}
			else{
				$content['title']      = '404 - This Page Does Not Exist';

	            $this->load->view('menu/V_header', $content);
				if ($this->session->userdata('ec_role') == 'Member') {
					$this->load->view('menu/V_menu_login');
				}
				else{
					$this->load->view('menu/V_menu');
				}
				$this->load->view('menu/V_error');
				$this->load->view('menu/V_footer');
			}
		}
		else{
			$this->session->set_flashdata('wrong', '<div class="alert alert-danger">Please login before add to cart</div>');
			redirect('login');
		}
	}

	public function add_cart_single($slug){

		if ($this->session->userdata('ec_role') == 'Member') {
			if (!empty($this->M_product_detail->checkProductId($slug))) {

				$detail = $this->M_product_detail->getProductDetail($slug);

				if ($detail['stock'] < 1) {
					$this->session->set_flashdata('wrong', '<div class="alert alert-danger">Product stock is not enough</div>');
					redirect('product/'.$slug);
				}
				else{
					$data = array(
						'product_image' => $detail['product_image'],
			            'id' 			=> $detail['product_id'], 
			            'name' 			=> $detail['product'], 
			            'price' 		=> $detail['price'], 
			            'discount' 		=> $detail['discount'],
			            'weight'		=> $detail['weight'],
			            'qty' 			=> 1 
			        );

			        if ($this->cart->insert($data)) {
			        	$cart = $this->cart->contents();
			        	redirect(base_url().'cart','refresh');
			        }
			        else{
			        	redirect(base_url(),'refresh');
			        }
			    }

			}
			else{
				$content['title']      = '404 - This Page Does Not Exist';

	            $this->load->view('menu/V_header', $content);
				if ($this->session->userdata('ec_role') == 'Member') {
					$this->load->view('menu/V_menu_login');
				}
				else{
					$this->load->view('menu/V_menu');
				}
				$this->load->view('menu/V_error');
				$this->load->view('menu/V_footer');
			}
		}
		else{
			$this->session->set_flashdata('wrong', '<div class="alert alert-danger">Please login before add to cart</div>');
			redirect('login');
		}

	}
 
    public function delete_cart($rowid){
        $data = array(
            'rowid' => $rowid, 
            'qty' => 0, 
        );
        $this->cart->update($data);
        redirect('cart','refresh');
    }

    public function checkout(){

    	if ($this->session->userdata('ec_role') == 'Member') {
    		$user_id = $this->session->userdata('ec_user_id');

    		$cart 	= $this->cart->contents();

			$total_price = 0;
			foreach ($cart as $dt_cart) {
				$total_price+= $dt_cart['qty'] * $dt_cart['price'];
			}

    		$data = array(
    					'trasaction_time'			=> date('H:i:s'),
    					'transaction_date'			=> date('Y-m-d'),
    					'user_id'					=> $user_id,
    					'shipping_name'				=> '',
    					'shipping_detail'			=> '',
    					'shipping_fee'				=> 0,
    					'discount'					=> 0,
    					'total_price'				=> $total_price,
    					'payment'					=> '',
    					'receipt_number'			=> '',
    					'shipping_status'			=> 0,
    					'date_payment'				=> '0000-00-00 00:00:00',
    					'date_shipping'				=> '0000-00-00 00:00:00',
    					'date_accept'				=> '0000-00-00 00:00:00',
    					'date_cancel'				=> '0000-00-00 00:00:00',
    					'transaction_name'			=> '',
    					'transaction_phone'			=> '',
    					'transaction_address'		=> '',
    					'transaction_province'		=> '',
    					'transaction_city'			=> '',
    					'transaction_sub_districts'	=> '',
    					'transaction_postal_code'	=> '',
    					'message'					=> '',
    					'user_agent'				=> $this->userAgent(),
    					'active_transaction'		=> 1
    				);

    		$insert = $this->M_cart->insertTransaction('ec_transaction', $data);
    		if($insert){
    			$transaction_id = $this->M_cart->getMaxIdTransaction($user_id);

    			foreach ($cart as $item) {
					$product_detail = array(
									'transaction_id'			=> $transaction_id['transaction_id'],
									'product_id'				=> $item['id'],
									'amount'					=> $item['qty'],
									'price'						=> $item['price'],
									'discount'					=> $item['discount'],
									'transaction_detail_active' => 1
								);
					$this->M_cart->insertProduct('ec_transaction_detail', $product_detail);
				}

				$this->cart->destroy();
				$data_session = array(
					'tot_cart' => ''
				);

				$this->session->set_userdata($data_session);
				$this->session->set_flashdata('success', '<div class="alert alert-success">Checkout is success. Please payment this transaction</div>');
				redirect('cart');

    		}
    		else{
	    		$this->session->set_flashdata('wrong', '<div class="alert alert-danger">Please login</div>');
				redirect('login');
	    	}	

    	}
    	else{
    		$this->session->set_flashdata('wrong', '<div class="alert alert-danger">Please login</div>');
			redirect('login');
    	}	
    }

    public function userAgent(){

		if ($this->agent->is_browser())
		{
	        $agent = $this->agent->browser().' '.$this->agent->version();
		}
		elseif ($this->agent->is_robot())
		{
	        $agent = $this->agent->robot();
		}
		elseif ($this->agent->is_mobile())
		{
		    $agent = $this->agent->mobile();
		}
		else
		{
		    $agent = 'Unidentified User Agent';
		}

		return $this->agent->platform()."-".$agent;

	}

}

/* End of file C_cart.php */
/* Location: ./application/modules/cart/controllers/C_cart.php */