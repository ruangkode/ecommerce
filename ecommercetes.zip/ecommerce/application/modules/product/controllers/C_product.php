<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_product extends MX_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->helper('text');
		$this->load->model('product/M_product');
	}

	public function index()
	{
		$content['title']  = 'Product';
		$data['product']   = $this->M_product->getProduct()->result_array();

		$this->load->view('menu/V_header', $content);
		if ($this->session->userdata('ec_role') == 'Member') {
			$this->load->view('menu/V_menu_login');
		}
		else{
			$this->load->view('menu/V_menu');
		}
		$this->load->view('V_content', $data);
		$this->load->view('menu/V_footer');
	}

	public function search()
	{

		$searchword = $this->input->get('search');

		$content['title']  		 = 'Product';
		$search 			  	 = strtolower(str_replace("+"," ",$searchword));
		$data['check_product']   = $this->M_product->getProductSearch($search)->num_rows();
		$data['product_search']  = $this->M_product->getProductSearch($search)->result_array();
		$data['msg_warning']     = 'Pencarian kelas dengan kata kunci <u>'.$search.'</u> tidak ditemukan';

		$this->load->view('menu/V_header', $content);
		if ($this->session->userdata('ec_role') == 'Member') {
			$this->load->view('menu/V_menu_login');
		}
		else{
			$this->load->view('menu/V_menu');
		}
		$this->load->view('V_content_search', $data);
		$this->load->view('menu/V_footer');

	}

}

/* End of file C_product.php */
/* Location: ./application/modules/product/controllers/C_product.php */