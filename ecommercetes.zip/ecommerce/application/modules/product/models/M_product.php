<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_product extends CI_Model {

	public function getProduct(){
		$this->db->select('product_id, product, slug, product_image, price, discount')
				 ->from('ec_product')
				 ->join('ec_category', 'ec_category.category_id = ec_product.category_id', 'inner')
				 ->where('is_disable', '0')
				 ->where('product_active', '1');
		$data = $this->db->get();
		return $data;
	}

	public function getProductSearch($search){
	 	$this->db->select('product_id, product, slug, product_image, price, discount')
	 			 ->from('ec_product')
				 ->join('ec_category', 'ec_category.category_id = ec_product.category_id', 'inner')
				 ->like('product', $search)
				 ->where('is_disable', '0')
				 ->where('product_active', '1');
	 	$data = $this->db->get();
	 	return $data;
	 }	

}

/* End of file M_product.php */
/* Location: ./application/modules/product/models/M_product.php */