<section class="banner-area organic-breadcrumb">
	<div class="container">
		<div class="breadcrumb-banner d-flex flex-wrap align-items-center justify-content-end">
			<div class="col-first">
				<h1>Shop page</h1>
				<nav class="d-flex align-items-center">
					<a href="<?= base_url()?>">Home<span class="lnr lnr-arrow-right"></span></a>
					<a href="<?= base_url()?>product">Shop</a>
				</nav>
			</div>
		</div>
	</div>
</section>

<div class="container">
	<div class="row">
		<div class="col-xl-12 col-lg-12 col-md-12">
			<section class="lattest-product-area pb-40 category-list">
				<div class="row">	
				<?php foreach ($product as $dt_product) { ?>
				<div class="col-lg-3 col-md-6">
					<div class="single-product">
						<img class="img-fluid" src="<?= $dt_product['product_image']?>" alt="">
						<div class="product-details">
							<h6><a href="<?= base_url() ?>product/<?= $dt_product['slug'] ?>" style="color: black"><?= word_limiter($dt_product['product'], 4)?></a></h6>
							<div class="price">
								<h6><?= "Rp. ".number_format($dt_product['price'], 0, ".", ".")?></h6>
								<?php if (!empty($dt_product['discount'])) {?>
									<h6 class="l-through"><?= "Rp. ".number_format($dt_product['discount'], 0, ".", ".")?></h6>
								<?php } ?>
							</div>
							<div class="prd-bottom">
								<a href="<?= base_url()?>add_cart_single/<?= $dt_product['slug'] ?>" class="social-info">
									<span class="ti-bag"></span>
									<p class="hover-text">add to bag</p>
								</a>
								<a href="<?= base_url() ?>product/<?= $dt_product['slug'] ?>" class="social-info">
									<span class="lnr lnr-move"></span>
									<p class="hover-text">view more</p>
								</a>
							</div>
						</div>
					</div>
				</div>
				<?php } ?>

				</div>
			</section>


		</div>
	</div>
</div>