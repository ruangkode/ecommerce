<section class="banner-area organic-breadcrumb">
  <div class="container">
    <div class="breadcrumb-banner d-flex flex-wrap align-items-center justify-content-end">
      <div class="col-first">
        <h1>Register</h1>
        <nav class="d-flex align-items-center">
          <a href="<?= base_url()?>">Home<span class="lnr lnr-arrow-right"></span></a>
          <a href="<?= base_url()?>login">Login</a>
        </nav>
      </div>
    </div>
  </div>
</section>


<section class="login_box_area section_gap">
  <div class="container">
    <div class="row">
      <div class="col-lg-6">
        <div class="login_box_img">
          <img class="img-fluid" src="<?= base_url()?>assets/template/main/img/login.jpg" alt="">
          <div class="hover">
            <h4>Ready your account?</h4>
            <p>There are advances being made in science and technology everyday, and a good example of this is the</p>
            <a class="primary-btn" href="<?= base_url()?>login">Login Now</a>
          </div>
        </div>
      </div>
      <div class="col-lg-6">
        <div class="login_form_inner">
          <h3 style="margin-top: -50px">Create an Account</h3>
          <div class="col-md-12">
            <?php echo $this->session->flashdata('wrong'); ?>
          </div>
          <form class="row login_form" action="<?= base_url()?>reg_account" method="post" id="contactForm" novalidate="novalidate">
            <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
            <div class="col-md-12 form-group">
              <input type="text" class="form-control" id="name_f" name="name_f" placeholder="First Name" onfocus="this.placeholder = ''" onblur="this.placeholder = 'First Name'" value="<?= $this->session->userdata('rg_f_name')?>" required>
            </div>
            <div class="col-md-12 form-group">
              <input type="text" class="form-control" id="name_l" name="name_l" placeholder="Last Name" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Last Name'" value="<?= $this->session->userdata('rg_l_name')?>" required>
            </div>
            <div class="col-md-12 form-group">
              <input type="text" class="form-control" id="usernamecheck" name="username" placeholder="Username" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Username'" value="<?= $this->session->userdata('rg_username')?>" required>
            </div>
            <p id="username_result" style="float: left; margin-left: 20px;">
            <div class="col-md-12 form-group">
              <input type="email" class="form-control" id="emailcheck"" name="email" placeholder="Email" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Email'" value="<?= $this->session->userdata('rg_email')?>" required>
            </div>
            <p id="email_result" style="float: left; margin-left: 20px;">
            <div class="col-md-12 form-group">
              <input type="password" class="form-control" id="pass1" name="password" placeholder="Password" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Password'" onkeyup="checkPass()" required>
            </div>
            <div id="error-pass1" style="float: left; margin-left: 20px;"></div>
            <div class="col-md-12 form-group">
              <div class="form-group">
              <input type="password" class="form-control" id="pass2" name="password_confirm" placeholder="Confirm Password" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Confirm Password'" onkeyup="checkConfirmPass()" required>
            </div>
            <div id="error-pass2" style="float: left; margin-left: 15px;"></div>
            <div class="col-md-12 form-group">
              <button type="submit" value="submit" class="primary-btn">Register</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>