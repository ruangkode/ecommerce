<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_register extends CI_Model {

	public function checkEmail($email){
		$this->db->select('user_id')
				 ->from('ec_user')
				 ->where('email', $email);
		$data = $this->db->get();
		return $data->num_rows();
	}

	public function checkUsername($username){
		$this->db->select('user_id')
				 ->from('ec_user')
				 ->where('login', $username);
		$data = $this->db->get();
		return $data->num_rows();
	}

	public function checkPassword($user_id){
		$this->db->select('pass')
				 ->from('ec_user')
				 ->where('user_id', $user_id);
		$data = $this->db->get();
		return $data->row_array();
	}

	public function checkId($email, $username){
		$this->db->select('user_id')
				 ->from('ec_user')
				 ->where('login', $username)
				 ->where('email', $email);
		$data = $this->db->get();
		return $data->row_array();		 
	}

	public function registerAccount($table, $data){
		$res = $this->db->insert($table, $data);
		return $res;
	}

}

/* End of file M_register.php */
/* Location: ./application/modules/register/models/M_register.php */