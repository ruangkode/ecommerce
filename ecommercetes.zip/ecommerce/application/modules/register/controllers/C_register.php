<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_register extends MX_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->library(array('user_agent', 'rajaongkir'));
		date_default_timezone_set("Asia/Jakarta");
		$this->load->model('register/M_register');
	}

	public function index()
	{
		$content['title']   = 'Create an Account';
		// $provinces 			= $this->rajaongkir->province();
		// $cities 			= $this->rajaongkir->city();

		// $data['pro']		= json_decode($provinces, TRUE);
		// $data['city']       = json_decode($cities, TRUE);

		$this->load->view('menu/V_header', $content);
		$this->load->view('menu/V_menu');
		$this->load->view('V_content');
		$this->load->view('menu/V_footer');
	}

	public function registerAccount(){
		$name_f  			= ucfirst(strip_tags($this->input->post('name_f')));
		$name_l  			= ucfirst(strip_tags($this->input->post('name_l')));
		$username   		= strip_tags($this->input->post('username'));
		$email      		= strip_tags($this->input->post('email'));
		$password   		= $this->input->post('password');
		$password_confirm 	= $this->input->post('password_confirm');

		if (empty($name_f) || empty($name_l) || empty($username) || empty($email) || empty($password) || empty($password_confirm)) {
			$this->session->set_flashdata('wrong', '<div class="alert alert-danger">Please complete all your data</div>');
			$this->setSessionReg($name_f, $name_l, $username, $email);
			redirect('signup');
		}
		elseif(!preg_match("/^[a-zA-Z ]*$/",$name_f)){
			$this->session->set_flashdata('wrong', '<div class="alert alert-danger">First name only letters and spaces are allowed</div>');
			$this->setSessionReg($name_f, $name_l, $username, $email);
			redirect('signup');
		}
		elseif(!preg_match("/^[a-zA-Z ]*$/",$name_l)){
			$this->session->set_flashdata('wrong', '<div class="alert alert-danger">Last name only letters and spaces are allowed</div>');
			$this->setSessionReg($name_f, $name_l, $username, $email);
			redirect('signup');
		}
		elseif ($this->M_register->checkUsername($username) > 0) {
			$this->session->set_flashdata('wrong', '<div class="alert alert-danger">Username is already use</div>');
			$this->setSessionReg($name_f, $name_l, $username, $email);
			redirect('signup');
		}
		elseif ($this->M_register->checkEmail($email) > 0) {
			$this->session->set_flashdata('wrong', '<div class="alert alert-danger">Email is already use</div>');
			$this->setSessionReg($name_f, $name_l, $username, $email);
			redirect('signup');
		}
		elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)){
			$this->session->set_flashdata('wrong', '<div class="alert alert-danger">Email format is wrong</div>');
			$this->setSessionReg($name_f, $name_l, $username, $email);
			redirect('signup'); 
		}
		else {

			$options = [
				    'cost' => 10,
				];
				
			$data = array(
						'login'				=> $username,
						'pass'				=> password_hash($password, PASSWORD_DEFAULT, $options),
						'email'				=> $email,
						'verification_code'	=> $this->randomCode(25),
						'last_login'		=> '0000:00:00 00:00:00',
						'user_agent'		=> $this->userAgent(),
						'approve'			=> '1',
						'is_locked'			=> '0',
						'add_time'			=> date('Y-m-d'),
						'disable_time'		=> '0000:00:00 00:00:00',
						'active_user'		=> '1'
					);
			$register = $this->M_register->registerAccount('ec_user', $data);
			if ($register) {

				$user = $this->M_register->checkId($email, $username);
				if(!empty($user['user_id'])){
					$detail = array(
							  'user_id'				=> $user['user_id'],
							  'name_f'				=> $name_f,
							  'name_l'				=> $name_l,
							  'photo'				=> base_url().'assets/template/main/img/user.png',
							  'phone'				=> '',
							  'address'				=> '',
							  'sub_districts'		=> '',
							  'districts'			=> '',
							  'province'			=> '',
							  'sub_districs_id'		=> '',
							  'districts_id'		=> '',
							  'province_id'			=> '',
							  'postal_code'			=> '',
							  'active_detail_user'	=> '1'
						 	);
					$this->M_register->registerAccount('ec_user_detail', $detail);

					$this->cleanSessionReg();
					$this->session->set_flashdata('wrong', '<div class="alert alert-success">Register account is success, please login</div>');
					redirect('signup');
				}
				else{
					$this->session->set_flashdata('wrong', '<div class="alert alert-danger">Register account is failed</div>');
					$this->setSessionReg($name_f, $name_l, $username, $email);
					redirect('signup');
				}

				
			}
			else{
				$this->session->set_flashdata('wrong', '<div class="alert alert-danger">Register account is failed</div>');
					$this->setSessionReg($name_f, $name_l, $username, $email);
				redirect('signup');
			}

		}

	}

	public function checkUsername(){
		$username   = $this->input->post('username');
		if (empty($username)) {
			echo 'not';
		}
		else{
			if ($this->M_register->checkUsername($username) > 0) {
				echo 'not';
			}
			else{
				echo 'ok';
			}
		}
	}

	public function checkEmail(){
		$email      = $this->input->post('email');

		if (empty($email)) {
			echo 'not';
		}
		else{
			if ($this->M_register->checkEmail($email) > 0) {
				echo 'not';
			}
			else{
				echo 'ok';
			}
		}
	}

	public function setSessionReg($name_f, $name_l, $username, $email){
		$data_session = array(
							'rg_f_name'  	=> $name_f,
							'rg_l_name'  	=> $name_l,
							'rg_username' 	=> $username,
							'rg_email'		=> $email
						);
		$this->session->set_userdata($data_session);
	}

	public function cleanSessionReg(){
		$data_session = array(
							'rg_f_name'  	=> '',
							'rg_l_name'  	=> '',
							'rg_username' 	=> '',
							'rg_email'		=> ''
						);
		$this->session->set_userdata($data_session);
	}

	function randomCode($length)
	{
	    $character= 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz123456789';
	    $string = '';
	    for ($i = 0; $i < $length; $i++) {
		  $pos = rand(0, strlen($character)-1);
		  $string .= $character{$pos};
	    }
	    return $string;
	}

	public function userAgent(){

		if ($this->agent->is_browser())
		{
	        $agent = $this->agent->browser().' '.$this->agent->version();
		}
		elseif ($this->agent->is_robot())
		{
	        $agent = $this->agent->robot();
		}
		elseif ($this->agent->is_mobile())
		{
		    $agent = $this->agent->mobile();
		}
		else
		{
		    $agent = 'Unidentified User Agent';
		}

		return $this->agent->platform()."-".$agent;

	}

}

/* End of file C_register.php */
/* Location: ./application/modules/register/controllers/C_register.php */