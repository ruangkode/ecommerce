<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_product_detail extends MX_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('product_detail/M_product_detail');
	}

	public function index($slug)
	{

		if (!empty($this->M_product_detail->checkProductId($slug))) {
			$content['title']  = 'Product Detail';
			$data['detail']    = $this->M_product_detail->getProductDetail($slug);

			$checkView   = $this->M_product_detail->checkViewProduct($slug);
            $where       = array('slug' => $slug);
            $data_update = array(
                        'views' => $checkView['views'] + 1
                    );
            $this->M_product_detail->updateView($where, 'ec_product', $data_update);

			$this->load->view('menu/V_header', $content);
			if ($this->session->userdata('ec_role') == 'Member') {
				$this->load->view('menu/V_menu_login');
			}
			else{
				$this->load->view('menu/V_menu');
			}
			$this->load->view('V_content', $data);
			$this->load->view('menu/V_footer');

		}
		else{
			$content['title']      = '404 - This Page Does Not Exist';

            $this->load->view('menu/V_header', $content);
			if ($this->session->userdata('ec_role') == 'Member') {
				$this->load->view('menu/V_menu_login');
			}
			else{
				$this->load->view('menu/V_menu');
			}
			$this->load->view('menu/V_error');
			$this->load->view('menu/V_footer');
		}

	}

}

/* End of file controllername.php */
/* Location: ./application/controllers/controllername.php */