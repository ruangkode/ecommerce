<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_product_detail extends CI_Model {

	public function checkProductId($slug){
		$this->db->select('product_id')
				 ->from('ec_product')
				 ->where('slug', $slug)
				 ->where('is_disable', '0')
				 ->where('product_active', '1');
		$data = $this->db->get();
		return $data->row_array();
	}

	public function checkStockProduct($slug){
		$this->db->select('stock')
				 ->from('ec_product')
				 ->where('slug', $slug)
				 ->where('is_disable', '0')
				 ->where('product_active', '1');
		$data = $this->db->get();
		return $data->row_array();
	}

	public function getProductDetail($slug){
		$this->db->select('product_id, category, product, slug, product_image, product_desc, price, stock, discount, weight, views')
				 ->from('ec_product')
				 ->join('ec_category', 'ec_category.category_id = ec_product.category_id', 'inner')
				 ->where('is_disable', '0')
				 ->where('product_active', '1')
				 ->where('slug', $slug);
		$data = $this->db->get();
		return $data->row_array();
	}	

	public function checkViewProduct($slug){
		$this->db->select('views')
				 ->from('ec_product')
				 ->where('slug', $slug)
				 ->where('is_disable', '0')
				 ->where('product_active', '1');
		$data = $this->db->get();
		return $data->row_array();		 
	}

	public function insertView($table, $data){
		$res = $this->db->insert($table, $data);
		return $res;
	}

	public function updateView($where, $table, $data){
		$data = $this->db->where($where)->update($table, $data);
		return $data;
	}

}

/* End of file M_product_detail.php */
/* Location: ./application/modules/product_detail/models/M_product_detail.php */