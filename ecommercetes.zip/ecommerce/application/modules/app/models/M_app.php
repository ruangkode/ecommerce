<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_app extends CI_Model {

	public function getProduct(){
		$this->db->select('product_id, product, slug, product_image, price, discount')
				 ->from('ec_product')
				 ->join('ec_category', 'ec_category.category_id = ec_product.category_id', 'inner')
				 ->where('is_disable', '0')
				 ->where('product_active', '1')
				 ->order_by('product_id', 'DESC')
				 ->limit(8);
		$data = $this->db->get();
		return $data;
	}

}

/* End of file M_app.php */
/* Location: ./application/modules/app/models/M_app.php */