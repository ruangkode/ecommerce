<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_app extends MX_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->helper('text');
		$this->load->model('app/M_app');
	}

	public function index()
	{
		$content['title']  = 'Karma Shop';
		$data['product']   = $this->M_app->getProduct()->result_array();

		$this->load->view('menu/V_header', $content);
		if ($this->session->userdata('ec_role') == 'Member') {
			$this->load->view('menu/V_menu_login');
		}
		else{
			$this->load->view('menu/V_menu');
		}
		$this->load->view('V_content', $data);
		$this->load->view('menu/V_footer');
	}

}

/* End of file C_app.php */
/* Location: ./application/modules/app/controllers/C_app.php */