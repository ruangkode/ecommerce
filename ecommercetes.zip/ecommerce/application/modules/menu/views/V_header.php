<!DOCTYPE html>
<html lang="en">
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="shortcut icon" href="<?= base_url()?>assets/template/main/img/fav.png">
	<meta name="author" content="ypratama45@gmail.com">
	<meta name="description" content="Ecommerce">
	<meta name="keywords" content="Karma Shop">
	<meta charset="UTF-8">
	<title><?= $title?></title>

	<link rel="stylesheet" href="<?= base_url()?>assets/template/main/css/linearicons.css">
	<link rel="stylesheet" href="<?= base_url()?>assets/template/main/css/font-awesome.min.css">
	<link rel="stylesheet" href="<?= base_url()?>assets/template/main/css/themify-icons.css">
	<link rel="stylesheet" href="<?= base_url()?>assets/template/main/css/bootstrap.css">
	<link rel="stylesheet" href="<?= base_url()?>assets/template/main/css/owl.carousel.css">
	<link rel="stylesheet" href="<?= base_url()?>assets/template/main/css/nice-select.css">
	<link rel="stylesheet" href="<?= base_url()?>assets/template/main/css/nouislider.min.css">
	<link rel="stylesheet" href="<?= base_url()?>assets/template/main/css/ion.rangeSlider.css" />
	<link rel="stylesheet" href="<?= base_url()?>assets/template/main/css/ion.rangeSlider.skinFlat.css" />
	<link rel="stylesheet" href="<?= base_url()?>assets/template/main/css/magnific-popup.css">
	<link rel="stylesheet" href="<?= base_url()?>assets/template/main/css/main.css">

</head>

<body>