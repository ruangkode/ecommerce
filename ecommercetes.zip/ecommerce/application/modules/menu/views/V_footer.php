<footer class="footer-area section_gap">
	<div class="container">
		<div class="row">
			<div class="col-lg-3  col-md-6 col-sm-6">
				<div class="single-footer-widget">
					<h6>About Us</h6>
					<p>
					Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore dolore
					magna aliqua.
					</p>
				</div>
			</div>
			<div class="col-lg-4  col-md-6 col-sm-6">
				<div class="single-footer-widget">
					<h6>Newsletter</h6>
					<p>Stay update with our latest</p>
					<div class="" id="mc_embed_signup">
						<form target="_blank" novalidate="true" action="https://spondonit.us12.list-manage.com/subscribe/post?u=1462626880ade1ac87bd9c93a&amp;id=92a4423d01" method="get" class="form-inline">
							<div class="d-flex flex-row">
								<input class="form-control" name="EMAIL" placeholder="Enter Email" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Email '" required="" type="email">
								<button class="click-btn btn btn-default"><i class="fa fa-long-arrow-right" aria-hidden="true"></i></button>
								<div style="position: absolute; left: -5000px;">
									<input name="b_36c4fd991d266f23781ded980_aefe40901a" tabindex="-1" value="" type="text">
								</div>
							</div>
							<div class="info"></div>
						</form>
					</div>
				</div>
			</div>
			<div class="col-lg-3  col-md-6 col-sm-6">
				<div class="single-footer-widget mail-chimp">
					<h6 class="mb-20">Instragram Feed</h6>
					<ul class="instafeed d-flex flex-wrap">
						<li><img src="<?= base_url()?>assets/template/main/img/i1.jpg" alt=""></li>
						<li><img src="<?= base_url()?>assets/template/main/img/i2.jpg" alt=""></li>
						<li><img src="<?= base_url()?>assets/template/main/img/i3.jpg" alt=""></li>
						<li><img src="<?= base_url()?>assets/template/main/img/i4.jpg" alt=""></li>
						<li><img src="<?= base_url()?>assets/template/main/img/i5.jpg" alt=""></li>
						<li><img src="<?= base_url()?>assets/template/main/img/i6.jpg" alt=""></li>
						<li><img src="<?= base_url()?>assets/template/main/img/i7.jpg" alt=""></li>
						<li><img src="<?= base_url()?>assets/template/main/img/i8.jpg" alt=""></li>
					</ul>
				</div>
			</div>
			<div class="col-lg-2 col-md-6 col-sm-6">
				<div class="single-footer-widget">
					<h6>Follow Us</h6>
					<p>Let us be social</p>
					<div class="footer-social d-flex align-items-center">
						<a href="#"><i class="fa fa-facebook"></i></a>
						<a href="#"><i class="fa fa-twitter"></i></a>
						<a href="#"><i class="fa fa-dribbble"></i></a>
						<a href="#"><i class="fa fa-behance"></i></a>
					</div>
				</div>
			</div>
		</div>
		<div class="footer-bottom d-flex justify-content-center align-items-center flex-wrap">
			<p class="footer-text m-0">
			Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved
			</p>
		</div>
	</div>
</footer>

<script src="<?= base_url()?>assets/template/main/js/vendor/jquery-2.2.4.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
<script src="<?= base_url()?>assets/template/main/js/vendor/bootstrap.min.js"></script>
<script src="<?= base_url()?>assets/template/main/js/jquery.ajaxchimp.min.js"></script>
<script src="<?= base_url()?>assets/template/main/js/jquery.nice-select.min.js"></script>
<script src="<?= base_url()?>assets/template/main/js/jquery.sticky.js"></script>
<script src="<?= base_url()?>assets/template/main/js/nouislider.min.js"></script>
<script src="<?= base_url()?>assets/template/main/js/countdown.js"></script>
<script src="<?= base_url()?>assets/template/main/js/jquery.magnific-popup.min.js"></script>
<script src="<?= base_url()?>assets/template/main/js/owl.carousel.min.js"></script>

<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCjCGmQ0Uq4exrzdcL6rvxywDDOvfAu6eE"></script>
<script src="<?= base_url()?>assets/template/main/js/gmaps.min.js"></script>
<script src="<?= base_url()?>assets/template/main/js/main.js"></script>

<script>

    $(document).ready(function(){
      $('#usernamecheck').blur(function(){
        var username = document.getElementById("usernamecheck").value;
        $.ajax({
          type: "POST",
          url: "<?= base_url()?>check_username",
          data: {'<?= $this->security->get_csrf_token_name(); ?>':'<?= $this->security->get_csrf_hash(); ?>', username:username},
          success: function (data){
            console.log(data);
            if(data === 'not'){
                document.getElementById('username_result').style.marginTop="-20px"; 
                $('#username_result').html('<font color="#f66">Username tidak tersedia, ganti yang lain</font>');
            } else {
                document.getElementById('username_result').style.marginTop="-20px"; 
                $('#username_result').html('<font color="#6f6">Username tersedia</font>');
            }
          }
       });
     });

    });

    $(document).ready(function(){
      $('#emailcheck').blur(function(){
        var email = document.getElementById("emailcheck").value;
        $.ajax({
          type: "POST",
          url: "<?= base_url()?>check_email",
          data: {'<?= $this->security->get_csrf_token_name(); ?>':'<?= $this->security->get_csrf_hash(); ?>', email:email},
          success: function (data){
            console.log(data);
            if(data === 'not'){
                document.getElementById('email_result').style.marginTop="-20px";
                $('#email_result').html('<font color="#f66">Email tidak tersedia, ganti yang lain</font>');
            } else {
                document.getElementById('email_result').style.marginTop="-20px";
                $('#email_result').html('<font color="#6f6">Email tersedia</font>');
            }
          }
       });
     });
    });

    function checkConfirmPass(){
        var neutralColor = '#fff'; // 'white';
        var badColor     = '#f66'; // 'red';
        var goodColor    = '#6f6'; // 'green';

        var password1 = getElm('pass1').value;
        var password2 = getElm('pass2').value;
        
        if (password2 !== password1) {
            setBGColor('error-pass2', badColor);
            setMarginTop('error-pass2', '-20px');
            $('#error-pass2').html('<p>Konfirmasi password tidak sama</p>');
        } else {
            setBGColor('error-pass2', goodColor);
            setMarginTop('error-pass2', '-20px');
            $('#error-pass2').html('<p>Konfirmasi password valid</p>');
        }

        function getElm(id) {
            return document.getElementById(id);
        }

        function setBGColor(id, value) {
            getElm(id).style.color = value;
        }

        function setMarginTop(id, value){
            getElm(id).style.marginTop = value;
        }

    }

    function checkPass() {
      var neutralColor = '#fff'; // 'white';
      var badColor     = '#f66'; // 'red';
      var goodColor    = '#6f6'; // 'green';
      
      var pass = getElm('pass1').value;
      var password2 = getElm('pass2').value;

        if (pass.length <= 7) {
            setBGColor('error-pass1', badColor);
            setMarginTop('error-pass1', '-20px');
            $('#error-pass1').html('<p>Password minimal 8 karakter</p>');
        }
        else{
            if(!checkCombination(pass)){
                setBGColor('error-pass1', badColor);
                setMarginTop('error-pass1', '-20px');
                $('#error-pass1').html('<p>Password harus mengandung huruf besar, huruf kecil, angka, dan tanda unik</p>');
            }else{
                setBGColor('error-pass1', goodColor);
                setMarginTop('error-pass1', '-20px');
                $('#error-pass1').html('<p>Password memenuhi kriteria</p>');
            }
        }

        function getElm(id) {
            return document.getElementById(id);
        }

        function checkCombination(str){
            var re = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).(?=.*[!@#$%&*^()-+={[,.?<>'";\/~`|}]).{8,}$/;
            return re.test(str);
        }     
        
        function setBGColor(id, value) {
            getElm(id).style.color = value;
        }

        function setMarginTop(id, value){
            getElm(id).style.marginTop = value;
        }

    }


</script>

</body>
</html>