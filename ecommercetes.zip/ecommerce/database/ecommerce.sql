-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 22, 2021 at 08:42 AM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ecommerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `ec_bank_confirmation`
--

CREATE TABLE IF NOT EXISTS `ec_bank_confirmation` (
`bank_confirmation_id` int(3) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `account_name` varchar(50) NOT NULL,
  `account_number` varchar(35) NOT NULL,
  `bank` varchar(30) NOT NULL,
  `active_bank` enum('0','1') NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `ec_bank_confirmation`
--

INSERT INTO `ec_bank_confirmation` (`bank_confirmation_id`, `logo`, `account_name`, `account_number`, `bank`, `active_bank`) VALUES
(1, 'http://app.zqop4dlf3v7jng1d.com/api/debug/assets/images/bank/bri.png', 'Karma Corporate', '456547-987-999', 'Bank BRI', '1');

-- --------------------------------------------------------

--
-- Table structure for table `ec_category`
--

CREATE TABLE IF NOT EXISTS `ec_category` (
`category_id` int(2) NOT NULL,
  `category` varchar(255) NOT NULL,
  `category_slug` varchar(255) NOT NULL,
  `add_time` datetime NOT NULL,
  `category_active` enum('0','1') NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `ec_category`
--

INSERT INTO `ec_category` (`category_id`, `category`, `category_slug`, `add_time`, `category_active`) VALUES
(1, 'Household', 'household', '2021-04-21 05:11:00', '1'),
(2, 'Slide', 'slide', '2021-04-21 05:11:00', '1'),
(3, 'Skate Shoe', 'skate-shoe', '2021-04-21 05:11:00', '1'),
(4, 'Running Shoe', 'running-shoe', '2021-04-21 05:11:00', '1'),
(5, 'Weightlifting Shoe', 'weightlifting-shoe', '2021-04-21 05:11:00', '1');

-- --------------------------------------------------------

--
-- Table structure for table `ec_product`
--

CREATE TABLE IF NOT EXISTS `ec_product` (
`product_id` int(11) NOT NULL,
  `category_id` int(2) NOT NULL,
  `product` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `product_image` varchar(255) NOT NULL,
  `product_desc` text NOT NULL,
  `price` int(11) NOT NULL,
  `stock` int(11) NOT NULL,
  `discount` int(11) NOT NULL,
  `weight` double NOT NULL,
  `views` int(11) NOT NULL,
  `add_time` datetime NOT NULL,
  `is_disable` enum('0','1') NOT NULL,
  `product_active` enum('0','1') NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `ec_product`
--

INSERT INTO `ec_product` (`product_id`, `category_id`, `product`, `slug`, `product_image`, `product_desc`, `price`, `stock`, `discount`, `weight`, `views`, `add_time`, `is_disable`, `product_active`) VALUES
(1, 1, 'Faded SkyBlu Denim Jeans', 'faded-skyblu-denim-jeans', 'http://localhost/ecommerce/assets/template/main/img/product/p1.jpg', 'Mill Oil is an innovative oil filled radiator with the most modern technology. If you are looking for something that can make your interior look awesome, and at the same time give you the pleasant warm feeling during the winter.', 1350000, 5, 0, 1000, 0, '2021-04-21 19:13:20', '0', '1'),
(2, 2, 'Adidas New Hammer Sole For Sport Person', 'adidas-new-hammer-sole-for-sport-person', 'http://localhost/ecommerce/assets/template/main/img/product/p2.jpg', 'Mill Oil is an innovative oil filled radiator with the most modern technology. If you are looking for something that can make your interior look awesome, and at the same time give you the pleasant warm feeling during the winter.', 990000, 3, 0, 1000, 18, '2021-04-21 19:13:20', '0', '1'),
(3, 3, 'Nike Air More Uptempo ''96', 'nike-air-more-uptempo-96', 'http://localhost/ecommerce/assets/template/main/img/product/p3.jpg', 'Mill Oil is an innovative oil filled radiator with the most modern technology. If you are looking for something that can make your interior look awesome, and at the same time give you the pleasant warm feeling during the winter.', 2569000, 3, 0, 1000, 1, '2021-04-21 19:13:20', '0', '1'),
(4, 4, 'Nike Air Huarache', 'nike-air-huarache', 'http://localhost/ecommerce/assets/template/main/img/product/p4.jpg', 'Mill Oil is an innovative oil filled radiator with the most modern technology. If you are looking for something that can make your interior look awesome, and at the same time give you the pleasant warm feeling during the winter.', 1799000, 3, 0, 1000, 1, '2021-04-21 19:13:20', '0', '1'),
(5, 1, 'Nike Crater Impact', 'nike-crater-impact', 'http://localhost/ecommerce/assets/template/main/img/product/p5.jpg', 'Mill Oil is an innovative oil filled radiator with the most modern technology. If you are looking for something that can make your interior look awesome, and at the same time give you the pleasant warm feeling during the winter.', 1429000, 3, 0, 1000, 0, '2021-04-21 19:13:20', '0', '1'),
(6, 1, 'Nike Air VaporMax Evo', 'nike-air-vapormax-evo', 'http://localhost/ecommerce/assets/template/main/img/product/p6.jpg', 'Mill Oil is an innovative oil filled radiator with the most modern technology. If you are looking for something that can make your interior look awesome, and at the same time give you the pleasant warm feeling during the winter.', 3089000, 3, 0, 1000, 17, '2021-04-21 19:13:20', '0', '1'),
(7, 1, 'Nike Air Max Pre-Day', 'nike-air-max-pre-day', 'http://localhost/ecommerce/assets/template/main/img/product/p7.jpg', 'Mill Oil is an innovative oil filled radiator with the most modern technology. If you are looking for something that can make your interior look awesome, and at the same time give you the pleasant warm feeling during the winter.', 1979000, 3, 0, 1000, 0, '2021-04-21 19:13:20', '0', '1'),
(8, 1, 'Nike SB Zoom Blazer Mid Premium', 'nike-sb-zoom-blazer-mid-premium', 'http://localhost/ecommerce/assets/template/main/img/product/p8.jpg', 'Mill Oil is an innovative oil filled radiator with the most modern technology. If you are looking for something that can make your interior look awesome, and at the same time give you the pleasant warm feeling during the winter.', 1799000, 3, 0, 1000, 14, '2021-04-21 19:13:20', '0', '1');

-- --------------------------------------------------------

--
-- Table structure for table `ec_transaction`
--

CREATE TABLE IF NOT EXISTS `ec_transaction` (
`transaction_id` int(11) NOT NULL,
  `trasaction_time` time NOT NULL,
  `transaction_date` date NOT NULL,
  `user_id` int(11) NOT NULL,
  `shipping_name` varchar(255) NOT NULL,
  `shipping_detail` varchar(255) NOT NULL,
  `shipping_fee` int(11) NOT NULL,
  `discount` int(11) NOT NULL,
  `total_price` int(11) NOT NULL,
  `payment` int(11) NOT NULL,
  `receipt_number` varchar(64) NOT NULL,
  `shipping_status` enum('0','1','2','3','4','5') NOT NULL COMMENT '0 : dibuat 1 : dibayar 2 : dikirim 3 : diterima 4 : menunggu konfirmasi 5 : dibatalkan',
  `date_payment` datetime NOT NULL,
  `date_shipping` datetime NOT NULL,
  `date_accept` datetime NOT NULL,
  `date_cancel` datetime NOT NULL,
  `transaction_name` varchar(35) NOT NULL,
  `transaction_phone` varchar(15) NOT NULL,
  `transaction_address` varchar(625) NOT NULL,
  `transaction_province` varchar(100) NOT NULL,
  `transaction_city` varchar(100) NOT NULL,
  `transaction_sub_districts` varchar(100) NOT NULL,
  `transaction_postal_code` varchar(15) NOT NULL,
  `message` varchar(625) NOT NULL,
  `user_agent` varchar(225) NOT NULL,
  `active_transaction` enum('0','1') NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `ec_transaction`
--

INSERT INTO `ec_transaction` (`transaction_id`, `trasaction_time`, `transaction_date`, `user_id`, `shipping_name`, `shipping_detail`, `shipping_fee`, `discount`, `total_price`, `payment`, `receipt_number`, `shipping_status`, `date_payment`, `date_shipping`, `date_accept`, `date_cancel`, `transaction_name`, `transaction_phone`, `transaction_address`, `transaction_province`, `transaction_city`, `transaction_sub_districts`, `transaction_postal_code`, `message`, `user_agent`, `active_transaction`) VALUES
(1, '13:38:17', '2021-04-22', 1, '', '', 0, 0, 990000, 0, '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', '', '', '', '', '', '', 'Windows 10-Chrome 89.0.4389.128', '0'),
(2, '13:39:06', '2021-04-22', 1, '', '', 0, 0, 990000, 0, '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', '', '', '', '', '', '', 'Windows 10-Chrome 89.0.4389.128', '0'),
(3, '13:39:47', '2021-04-22', 1, '', '', 0, 0, 990000, 0, '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', '', '', '', '', '', '', 'Windows 10-Chrome 89.0.4389.128', '0'),
(4, '13:40:08', '2021-04-22', 1, '', '', 0, 0, 990000, 0, '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', '', '', '', '', '', '', 'Windows 10-Chrome 89.0.4389.128', '0');

-- --------------------------------------------------------

--
-- Table structure for table `ec_transaction_detail`
--

CREATE TABLE IF NOT EXISTS `ec_transaction_detail` (
`transaction_detail_id` int(11) NOT NULL,
  `transaction_id` int(11) NOT NULL,
  `product_id` int(5) NOT NULL,
  `amount` int(5) NOT NULL,
  `price` int(11) NOT NULL,
  `discount` int(11) NOT NULL,
  `transaction_detail_active` enum('0','1') NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `ec_transaction_detail`
--

INSERT INTO `ec_transaction_detail` (`transaction_detail_id`, `transaction_id`, `product_id`, `amount`, `price`, `discount`, `transaction_detail_active`) VALUES
(1, 3, 2, 1, 990000, 0, '0'),
(2, 4, 2, 1, 990000, 0, '0');

-- --------------------------------------------------------

--
-- Table structure for table `ec_user`
--

CREATE TABLE IF NOT EXISTS `ec_user` (
`user_id` int(11) NOT NULL,
  `login` varchar(64) NOT NULL,
  `pass` varchar(64) NOT NULL,
  `email` varchar(64) NOT NULL,
  `verification_code` varchar(25) NOT NULL,
  `last_login` datetime NOT NULL,
  `user_agent` varchar(255) NOT NULL,
  `approve` enum('0','1') NOT NULL,
  `is_locked` enum('0','1') NOT NULL,
  `add_time` datetime NOT NULL,
  `disable_time` datetime NOT NULL,
  `active_user` enum('0','1') NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `ec_user`
--

INSERT INTO `ec_user` (`user_id`, `login`, `pass`, `email`, `verification_code`, `last_login`, `user_agent`, `approve`, `is_locked`, `add_time`, `disable_time`, `active_user`) VALUES
(1, 'pratama45', '$2y$10$TeyPeZz6y2bCV7fDAOfx7.E5TZ8s0KAj0X.Z91ouuG4relZWBu4.W', 'tama@gmail.com', 'jx9TJhhjRNwskjDNJxLAiofj4', '2021-04-22 13:05:26', 'Windows 10-Chrome 89.0.4389.128', '1', '0', '2021-04-21 00:00:00', '0000-00-00 00:00:00', '1'),
(2, 'Fiesta', '$2y$10$65MHiyV7NMEBVc6sPGwQWeIJEB/wqW99Deju5NRF0/8il4Zmtqgye', 'fiesta@gmail.com', 'U44whqbTgsKE9UiHJWiGtLoF8', '0000-00-00 00:00:00', 'Windows 10-Chrome 89.0.4389.128', '1', '0', '2021-04-21 00:00:00', '0000-00-00 00:00:00', '1'),
(3, 'denis', '$2y$10$jjEoDTmg4h1EUijy4vzwPu0CV0xvPB.vPHf0cr5i8aUA6TNwzGchy', 'denis@gmail.com', 'NQoUdLINFXf8BZd6rXQ7K4lWy', '0000-00-00 00:00:00', 'Windows 10-Chrome 89.0.4389.128', '1', '0', '2021-04-21 00:00:00', '0000-00-00 00:00:00', '1');

-- --------------------------------------------------------

--
-- Table structure for table `ec_user_detail`
--

CREATE TABLE IF NOT EXISTS `ec_user_detail` (
`user_detail_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name_f` varchar(30) NOT NULL,
  `name_l` varchar(30) NOT NULL,
  `photo` varchar(625) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `address` text NOT NULL,
  `sub_districts` varchar(64) NOT NULL,
  `districts` varchar(64) NOT NULL,
  `province` varchar(30) NOT NULL,
  `sub_districs_id` int(11) NOT NULL,
  `districts_id` int(11) NOT NULL,
  `province_id` int(11) NOT NULL,
  `postal_code` varchar(15) NOT NULL,
  `active_detail_user` enum('0','1') NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `ec_user_detail`
--

INSERT INTO `ec_user_detail` (`user_detail_id`, `user_id`, `name_f`, `name_l`, `photo`, `phone`, `address`, `sub_districts`, `districts`, `province`, `sub_districs_id`, `districts_id`, `province_id`, `postal_code`, `active_detail_user`) VALUES
(1, 1, 'Yudha', 'Pratama', 'http://localhost/ecommerce/assets/template/main/img/user.png', '', '', '', '', '', 0, 0, 0, '', '1'),
(2, 2, 'Tama', 'Fiesta', 'http://localhost/ecommerce/assets/template/main/img/user.png', '', '', '', '', '', 0, 0, 0, '', '1'),
(3, 3, 'Rendi', 'Denis', 'http://localhost/ecommerce/assets/template/main/img/user.png', '', '', '', '', '', 0, 0, 0, '', '1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ec_bank_confirmation`
--
ALTER TABLE `ec_bank_confirmation`
 ADD PRIMARY KEY (`bank_confirmation_id`);

--
-- Indexes for table `ec_category`
--
ALTER TABLE `ec_category`
 ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `ec_product`
--
ALTER TABLE `ec_product`
 ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `ec_transaction`
--
ALTER TABLE `ec_transaction`
 ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `ec_transaction_detail`
--
ALTER TABLE `ec_transaction_detail`
 ADD PRIMARY KEY (`transaction_detail_id`);

--
-- Indexes for table `ec_user`
--
ALTER TABLE `ec_user`
 ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `ec_user_detail`
--
ALTER TABLE `ec_user_detail`
 ADD PRIMARY KEY (`user_detail_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ec_bank_confirmation`
--
ALTER TABLE `ec_bank_confirmation`
MODIFY `bank_confirmation_id` int(3) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `ec_category`
--
ALTER TABLE `ec_category`
MODIFY `category_id` int(2) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `ec_product`
--
ALTER TABLE `ec_product`
MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `ec_transaction`
--
ALTER TABLE `ec_transaction`
MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `ec_transaction_detail`
--
ALTER TABLE `ec_transaction_detail`
MODIFY `transaction_detail_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `ec_user`
--
ALTER TABLE `ec_user`
MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `ec_user_detail`
--
ALTER TABLE `ec_user_detail`
MODIFY `user_detail_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
